身份证驱动安装说明:
	1, 安装 64位/32位系统驱动.
	2, 安装 HxgcIDReader.exe.